"""Exact interleavings in the native embedder's frozen coordinate picture.

A partition may borrow either side from any of the three orders, forward or
reversed, with identical canonically oriented strand pairs solved once. The
three integer costs are outside-chip reserved volume, reserved volume, and
source-edge rank span.  No packing, capacity test, or physical conversion
occurs here.  Coordinates belong to the current occupants of fixed slots;
the caller applies the returned order to those slots.

Spatial moves charge interval starts and ends when their endpoints are
emitted.  Contact-order moves charge a vertex's complete arms when it is
emitted.  In both cases a prefix pair is a sufficient state.  Preparation is O(n + |E|); the merge grid takes O(|unit| * |rest|)
work. Only the byte traceback grid is quadratic storage. Neighbor crossings
and endpoint events supply costs directly to two integer value rows.
"""

from __future__ import annotations

import time

import numpy as np
from numba import njit


@njit(cache=True)
def _check_arrays(orders, coords, indptr, indices, monotone_axis):
    """Linear validation also keeps unchecked compiled indexing safe."""
    n = orders.shape[1]
    for axis in range(3):
        seen = np.zeros(n, dtype=np.bool_)
        for i in range(n):
            v = orders[axis, i]
            if v < 0 or v >= n or seen[v]:
                raise ValueError("each order must be a permutation of the vertices")
            seen[v] = True
    maximum = np.int64(1)
    for axis in range(2):
        for v in range(n):
            if coords[axis, v] < 1:
                raise ValueError("coordinates must be positive")
            maximum = max(maximum, coords[axis, v])
    if 0 <= monotone_axis < 2:
        for i in range(1, n):
            if (coords[monotone_axis, orders[monotone_axis, i]]
                    < coords[monotone_axis, orders[monotone_axis, i - 1]]):
                raise ValueError("spatial slots must be nondecreasing in their order")
    if indptr[0] != 0 or indptr[n] != indices.size:
        raise ValueError("invalid CSR offsets")
    for v in range(n):
        if (indptr[v] < 0 or indptr[v] > indptr[v + 1]
                or indptr[v + 1] > indices.size):
            raise ValueError("invalid CSR offsets")
        for e in range(indptr[v], indptr[v + 1]):
            if indices[e] < 0 or indices[e] >= n or indices[e] == v:
                raise ValueError("invalid CSR neighbor")
    return maximum


def check_cost_bounds(n, edge_count, chip_m, maximum):
    """Cheap Python-integer bounds for an already validated source and slots.

    Trusted sweep callers may check these once and use ``checked=False`` for
    their queries: permutations and fixed-slot reassignment preserve the bounds.
    """
    n, edge_count, chip_m, maximum = map(int, (n, edge_count, chip_m, maximum))
    limit = int(np.iinfo(np.int64).max)
    if n < 0 or edge_count < 0 or maximum < 1:
        raise ValueError("invalid source size or coordinate maximum")
    if chip_m < 1:
        raise ValueError("chip_m must be positive")
    if chip_m > limit // 2:
        raise OverflowError("chip extent exceeds safe int64 arithmetic")
    # Partial spatial endpoint charges can be negative; bound their magnitude
    # as well as the nonnegative cost of complete reservations.
    if 2 * n * (maximum // 2 + 2) > limit:
        raise OverflowError("reserved-volume bounds exceed int64")
    if 3 * edge_count * max(n - 1, 0) > limit:
        raise OverflowError("rank-span bounds exceed int64")


def _check_inputs(orders, coords, indptr, indices, chip_m, monotone_axis=-1):
    if orders.ndim != 2 or orders.shape[0] != 3:
        raise ValueError("orders must have shape (3, n)")
    n = orders.shape[1]
    if coords.shape != (2, n):
        raise ValueError("coords must have shape (2, n)")
    if indptr.shape != (n + 1,) or indices.ndim != 1 or indices.size % 2:
        raise ValueError("source must be an undirected graph in CSR form")
    # Reject an unsafe chip extent before a compiled call can coerce it.
    check_cost_bounds(n, indices.size // 2, chip_m, 1)
    maximum = int(_check_arrays(orders, coords, indptr, indices, monotone_axis))
    check_cost_bounds(n, indices.size // 2, chip_m, maximum)


@njit(cache=True)
def _less(a0, a1, a2, b0, b1, b2):
    return a0 < b0 or (a0 == b0 and (a1 < b1 or (a1 == b1 and a2 < b2)))


@njit(cache=True)
def _interval_cost(lo, hi, lane, chip_m):
    first = (lo - 1) // 2
    last = hi // 2
    total = last - first + 1
    if lane > 2 * chip_m - 1:
        return total, total
    outside = max(0, last - chip_m + 1) - max(0, first - chip_m)
    return outside, total


@njit(cache=True)
def _ranks(order):
    result = np.empty(order.size, dtype=np.int64)
    for i in range(order.size):
        result[order[i]] = i
    return result


@njit(cache=True)
def _bounds(orders, coords, indptr, indices):
    """Orientation 0 is vertical, 1 horizontal; inactive bounds are -1."""
    n = orders.shape[1]
    trank = _ranks(orders[2])
    lo = np.full((2, n), -1, dtype=np.int64)
    hi = np.full((2, n), -1, dtype=np.int64)
    for v in range(n):
        for e in range(indptr[v], indptr[v + 1]):
            u = indices[e]
            orientation = 1 if trank[v] < trank[u] else 0
            value = coords[1 - orientation, u]
            if lo[orientation, v] < 0:
                lo[orientation, v] = value
                hi[orientation, v] = value
            else:
                lo[orientation, v] = min(lo[orientation, v], value)
                hi[orientation, v] = max(hi[orientation, v], value)
        if lo[0, v] >= 0 and lo[1, v] >= 0:
            for orientation in range(2):
                value = coords[1 - orientation, v]
                lo[orientation, v] = min(lo[orientation, v], value)
                hi[orientation, v] = max(hi[orientation, v], value)
    return lo, hi


@njit(cache=True)
def _score_from_bounds(orders, coords, indptr, indices, chip_m, rank_axis, lo, hi):
    outside = np.int64(0)
    volume = np.int64(0)
    span = np.int64(0)
    n = orders.shape[1]
    for orientation in range(2):
        for v in range(n):
            if lo[orientation, v] >= 0:
                out, size = _interval_cost(
                    lo[orientation, v], hi[orientation, v],
                    coords[orientation, v], chip_m,
                )
                outside += out
                volume += size
    for axis in range(3):
        if rank_axis >= 0 and axis != rank_axis:
            continue
        rank = _ranks(orders[axis])
        for v in range(n):
            for e in range(indptr[v], indptr[v + 1]):
                u = indices[e]
                if v < u:
                    span += abs(rank[v] - rank[u])
    return outside, volume, span


@njit(cache=True)
def _score(orders, coords, indptr, indices, chip_m, rank_axis):
    lo, hi = _bounds(orders, coords, indptr, indices)
    return _score_from_bounds(orders, coords, indptr, indices, chip_m, rank_axis, lo, hi)


def score_layout(orders, coords, indptr, indices, chip_m):
    """Return the full three-component objective (isolates contribute zero)."""
    orders = np.asarray(orders, dtype=np.int64)
    coords = np.asarray(coords, dtype=np.int64)
    indptr = np.asarray(indptr, dtype=np.int64)
    indices = np.asarray(indices, dtype=np.int64)
    chip_m = int(chip_m)
    _check_inputs(orders, coords, indptr, indices, chip_m)
    return tuple(int(x) for x in _score(
        orders, coords, indptr, indices, chip_m, -1,
    ))


@njit(cache=True)
def _strand_summary(sequence, n, coords, indptr, indices, axis, trank, lo):
    """Facts depending on one ordered strand; cached for the whole query."""
    positions = np.full(n, -1, dtype=np.int64)
    before = np.zeros(sequence.size, dtype=np.int64)
    hull = np.full((sequence.size, 4), -1, dtype=np.int64)
    extrema = np.empty((n, 2), dtype=np.int64)
    extrema[:, 0] = sequence.size
    extrema[:, 1] = -1
    for i in range(sequence.size):
        positions[sequence[i]] = i
    for i in range(sequence.size):
        v = sequence[i]
        for e in range(indptr[v], indptr[v + 1]):
            u = indices[e]
            position = positions[u]
            if position < 0:
                continue
            early = position < i
            if early:
                before[i] += 1
            if axis == 2:
                offset = 0 if early else 2
                value = coords[1 if early else 0, u]
                if hull[i, offset] < 0:
                    hull[i, offset] = value
                else:
                    hull[i, offset] = min(hull[i, offset], value)
                hull[i, offset + 1] = max(hull[i, offset + 1], value)
    if axis < 2:
        changing = 1 - axis
        for v in range(n):
            if lo[changing, v] < 0:
                continue
            for e in range(indptr[v], indptr[v + 1]):
                u = indices[e]
                endpoint = trank[v] < trank[u] if axis == 0 else trank[u] < trank[v]
                position = positions[u]
                if endpoint and position >= 0:
                    extrema[v, 0] = min(extrema[v, 0], position)
                    extrema[v, 1] = max(extrema[v, 1], position)
            position = positions[v]
            if lo[0, v] >= 0 and lo[1, v] >= 0 and position >= 0:
                extrema[v, 0] = min(extrema[v, 0], position)
                extrema[v, 1] = max(extrema[v, 1], position)
    return positions, before, hull, extrema


@njit(cache=True)
def _ordered_cross(sequence, opposite, positions, indptr, indices):
    """Scatter adjacency in opposite order; no sorting or dense prefix grid."""
    offsets = np.zeros(sequence.size + 1, dtype=np.int64)
    for u in opposite:
        for e in range(indptr[u], indptr[u + 1]):
            i = positions[indices[e]]
            if i >= 0:
                offsets[i + 1] += 1
    for i in range(sequence.size):
        offsets[i + 1] += offsets[i]
    cursor = offsets[:-1].copy()
    neighbors = np.empty(offsets[-1], dtype=np.int64)
    for j in range(opposite.size):
        u = opposite[j]
        for e in range(indptr[u], indptr[u + 1]):
            i = positions[indices[e]]
            if i >= 0:
                neighbors[cursor[i]] = j
                cursor[i] += 1
    return offsets, neighbors


@njit(cache=True)
def _contact_events(sequence, opposite, positions, same_hull, coords,
                    indptr, indices, chip_m):
    """d cross-neighbors give exactly d+1 complete arm-cost states."""
    offsets, crossings = _ordered_cross(sequence, opposite, positions, indptr, indices)
    state_offsets = offsets + np.arange(sequence.size + 1)
    costs = np.zeros((state_offsets[-1], 2), dtype=np.int64)
    # One reusable suffix workspace; total visits are linear in cross edges.
    suffix_min = np.empty(crossings.size + 1, dtype=np.int64)
    suffix_max = np.empty(crossings.size + 1, dtype=np.int64)
    for i in range(sequence.size):
        v = sequence[i]
        start, end = offsets[i], offsets[i + 1]
        suffix_min[end], suffix_max[end] = same_hull[i, 2], same_hull[i, 3]
        for k in range(end - 1, start - 1, -1):
            value = coords[0, opposite[crossings[k]]]
            suffix_min[k] = value if suffix_min[k + 1] < 0 else min(value, suffix_min[k + 1])
            suffix_max[k] = max(value, suffix_max[k + 1])
        early_min, early_max = same_hull[i, 0], same_hull[i, 1]
        for k in range(start, end + 1):
            late_min, late_max = suffix_min[k], suffix_max[k]
            has_v, has_h = early_min >= 0, late_min >= 0
            outside, volume = 0, 0
            if has_v:
                low, high = early_min, early_max
                if has_h:
                    low, high = min(low, coords[1, v]), max(high, coords[1, v])
                out, size = _interval_cost(low, high, coords[0, v], chip_m)
                outside += out
                volume += size
            if has_h:
                low, high = late_min, late_max
                if has_v:
                    low, high = min(low, coords[0, v]), max(high, coords[0, v])
                out, size = _interval_cost(low, high, coords[1, v], chip_m)
                outside += out
                volume += size
            costs[k + i, 0], costs[k + i, 1] = outside, volume
            if k < end:
                value = coords[1, opposite[crossings[k]]]
                early_min = value if early_min < 0 else min(early_min, value)
                early_max = max(early_max, value)
    return offsets, crossings, state_offsets, costs


@njit(cache=True)
def _spatial_unary(orders, coords, axis, lo, hi, chip_m):
    n = orders.shape[1]
    coefficients = np.empty((n, 6), dtype=np.int64)
    unary = np.zeros((n, 2), dtype=np.int64)
    outside = np.empty(n, dtype=np.bool_)
    for k in range(n):
        value = coords[axis, orders[axis, k]]
        first, last = (value - 1) // 2, value // 2
        coefficients[k, 0] = 1 - first
        coefficients[k, 1] = last
        coefficients[k, 2] = -max(0, first - chip_m)
        coefficients[k, 3] = 1 - first
        coefficients[k, 4] = max(0, last - chip_m + 1)
        coefficients[k, 5] = last
        outside[k] = value > 2 * chip_m - 1
        if lo[axis, k] >= 0:
            unary[k, 0], unary[k, 1] = _interval_cost(lo[axis, k], hi[axis, k], 1, chip_m)
    return coefficients, unary, outside


@njit(cache=True)
def _spatial_events(own, other, coords, axis, own_size, other_size, chip_m, by_owner):
    """At most three endpoint-counter events per contact net on one strand.

    Counting redistribution orders A events by (vertex, opposite prefix) and
    B events by opposite prefix. Thus the fill only visits actual events.
    """
    n = own.shape[0]
    owners = np.empty(3 * n, dtype=np.int64)
    thresholds = np.empty(3 * n, dtype=np.int64)
    kinds = np.empty(3 * n, dtype=np.int64)
    changes = np.empty(3 * n, dtype=np.int64)
    used = 0
    for v in range(n):
        first, last = own[v, 0], own[v, 1]
        if last < 0:
            continue
        outside = 1 if coords[1 - axis, v] > 2 * chip_m - 1 else 0
        owners[used], thresholds[used] = first, 0
        kinds[used], changes[used] = outside, 1
        used += 1
        threshold = other[v, 0] + 1
        if threshold <= other_size:
            owners[used], thresholds[used] = first, threshold
            kinds[used], changes[used] = outside, -1
            used += 1
        owners[used], thresholds[used] = last, other[v, 1] + 1
        kinds[used], changes[used] = 2 + outside, 1
        used += 1
    # Stable threshold buckets, followed by owner buckets when A needs both.
    threshold_ptr = np.zeros(other_size + 2, dtype=np.int64)
    for e in range(used):
        threshold_ptr[thresholds[e] + 1] += 1
    for j in range(other_size + 1):
        threshold_ptr[j + 1] += threshold_ptr[j]
    cursor = threshold_ptr[:-1].copy()
    ordered = np.empty(used, dtype=np.int64)
    for e in range(used):
        at = cursor[thresholds[e]]
        ordered[at] = e
        cursor[thresholds[e]] += 1
    if by_owner:
        offsets = np.zeros(own_size + 1, dtype=np.int64)
        for e in range(used):
            offsets[owners[e] + 1] += 1
        for i in range(own_size):
            offsets[i + 1] += offsets[i]
        cursor = offsets[:-1].copy()
        result = np.empty((used, 3), dtype=np.int64)
        for k in range(used):
            e = ordered[k]
            at = cursor[owners[e]]
            result[at, 0] = thresholds[e]
            result[at, 1] = kinds[e]
            result[at, 2] = changes[e]
            cursor[owners[e]] += 1
    else:
        offsets = threshold_ptr
        result = np.empty((used, 3), dtype=np.int64)
        for k in range(used):
            e = ordered[k]
            result[k, 0] = owners[e]
            result[k, 1] = kinds[e]
            result[k, 2] = changes[e]
    return offsets, result


@njit(cache=True)
def _spatial_price(counts, coefficients, unary, slot_outside):
    volume = ((counts[0] + counts[1]) * coefficients[0]
              + (counts[2] + counts[3]) * coefficients[1] + unary[1])
    outside = (counts[0] * coefficients[2] + counts[1] * coefficients[3]
               + counts[2] * coefficients[4] + counts[3] * coefficients[5])
    outside += unary[1] if slot_outside else unary[0]
    return outside, volume


@njit(cache=True)
def _fill_contact(part, rest, before_a, before_b, pb, indptr, indices,
                  a_offsets, a_cross, a_states, a_cost, b_states, b_cost):
    p, q = part.size, rest.size
    values = np.zeros((2, q + 1, 3), dtype=np.int64)
    parent = np.zeros((p + 1, q + 1), dtype=np.uint8)
    emitted_a = np.zeros(q, dtype=np.int64)
    cut_a = np.int64(0)
    updates = 0
    for i in range(p + 1):
        row, previous = i % 2, 1 - i % 2
        if i:
            v = part[i - 1]
            cut_a += indptr[v + 1] - indptr[v] - 2 * before_a[i - 1]
            for e in range(indptr[v], indptr[v + 1]):
                j = pb[indices[e]]
                if j >= 0:
                    emitted_a[j] += 1
                    updates += 1
            a_cursor, a_end = a_offsets[i - 1], a_offsets[i]
        else:
            a_cursor, a_end = 0, 0
        cut = cut_a
        for j in range(q + 1):
            if j:
                v = rest[j - 1]
                cut += indptr[v + 1] - indptr[v] - 2 * (before_b[j - 1] + emitted_a[j - 1])
            if i == 0 and j == 0:
                continue
            if i:
                while a_cursor < a_end and a_cross[a_cursor] < j:
                    a_cursor += 1
                    updates += 1
                state = a_states[i - 1] + a_cursor - a_offsets[i - 1]
                out = values[previous, j, 0] + a_cost[state, 0]
                size = values[previous, j, 1] + a_cost[state, 1]
                span = values[previous, j, 2] + cut
            else:
                out, size, span = 0, 0, 0
            if j:
                state = b_states[j - 1] + emitted_a[j - 1]
                bo = values[row, j - 1, 0] + b_cost[state, 0]
                bs = values[row, j - 1, 1] + b_cost[state, 1]
                br = values[row, j - 1, 2] + cut
                if i == 0 or _less(bo, bs, br, out, size, span):
                    out, size, span = bo, bs, br
                    parent[i, j] = 1
            values[row, j, 0], values[row, j, 1], values[row, j, 2] = out, size, span
    return parent, values[p % 2, q].copy(), updates


@njit(cache=True)
def _fill_spatial(part, rest, before_a, before_b, pb, indptr, indices,
                  a_offsets, a_events, b_offsets, b_events, coefficients, unary, slot_outside):
    p, q = part.size, rest.size
    values = np.zeros((2, q + 1, 3), dtype=np.int64)
    parent = np.zeros((p + 1, q + 1), dtype=np.uint8)
    emitted_a = np.zeros(q, dtype=np.int64)
    b_counts = np.zeros((q, 4), dtype=np.int64)
    a_counts = np.zeros(4, dtype=np.int64)
    cut_a = np.int64(0)
    updates = 0
    for i in range(p + 1):
        row, previous = i % 2, 1 - i % 2
        if i:
            v = part[i - 1]
            cut_a += indptr[v + 1] - indptr[v] - 2 * before_a[i - 1]
            for e in range(indptr[v], indptr[v + 1]):
                j = pb[indices[e]]
                if j >= 0:
                    emitted_a[j] += 1
                    updates += 1
            a_cursor, a_end = a_offsets[i - 1], a_offsets[i]
            a_counts[:] = 0
        else:
            a_cursor, a_end = 0, 0
        for e in range(b_offsets[i], b_offsets[i + 1]):
            b_counts[b_events[e, 0], b_events[e, 1]] += b_events[e, 2]
            updates += 1
        cut = cut_a
        for j in range(q + 1):
            if j:
                v = rest[j - 1]
                cut += indptr[v + 1] - indptr[v] - 2 * (before_b[j - 1] + emitted_a[j - 1])
            if i == 0 and j == 0:
                continue
            k = i + j - 1
            if i:
                while a_cursor < a_end and a_events[a_cursor, 0] <= j:
                    a_counts[a_events[a_cursor, 1]] += a_events[a_cursor, 2]
                    a_cursor += 1
                    updates += 1
                ao, av = _spatial_price(a_counts, coefficients[k], unary[part[i - 1]], slot_outside[k])
                out = values[previous, j, 0] + ao
                size = values[previous, j, 1] + av
                span = values[previous, j, 2] + cut
            else:
                out, size, span = 0, 0, 0
            if j:
                bo, bv = _spatial_price(b_counts[j - 1], coefficients[k], unary[rest[j - 1]], slot_outside[k])
                bo += values[row, j - 1, 0]
                bs = values[row, j - 1, 1] + bv
                br = values[row, j - 1, 2] + cut
                if i == 0 or _less(bo, bs, br, out, size, span):
                    out, size, span = bo, bs, br
                    parent[i, j] = 1
            values[row, j, 0], values[row, j, 1], values[row, j, 2] = out, size, span
    return parent, values[p % 2, q].copy(), updates


@njit(cache=True)
def _trace_differs(part, rest, parent, order):
    i, j = part.size, rest.size
    for k in range(order.size - 1, -1, -1):
        if parent[i, j] == 0:
            i -= 1
            v = part[i]
        else:
            j -= 1
            v = rest[j]
        if v != order[k]:
            return True
    return False


@njit(cache=True)
def _traceback(part, rest, parent):
    result = np.empty(part.size + rest.size, dtype=np.int64)
    i, j = part.size, rest.size
    for k in range(result.size - 1, -1, -1):
        if parent[i, j] == 0:
            i -= 1
            result[k] = part[i]
        else:
            j -= 1
            result[k] = rest[j]
    return result


def _prepare_transitions(orders, coords, indptr, indices, axis, part, rest,
                         chip_m, trank, lo, hi, cache=None, deadline=None):
    """Linear event preparation, with summaries shared across donor candidates."""
    if cache is None:
        cache = {}
    def expired():
        return deadline is not None and time.perf_counter() >= deadline

    summaries = []
    for strand in (part, rest):
        if expired():
            return None
        key = strand.tobytes()
        if key not in cache:
            cache[key] = _strand_summary(strand, orders.shape[1], coords, indptr,
                                         indices, axis, trank, lo)
        summaries.append(cache[key])
    if expired():
        return None
    sa, sb = summaries
    common = (sa[1], sb[1], sb[0], indptr, indices)
    if axis == 2:
        a = _contact_events(part, rest, sa[0], sa[2], coords, indptr, indices, chip_m)
        if expired():
            return None
        b = _contact_events(rest, part, sb[0], sb[2], coords, indptr, indices, chip_m)
        return axis, common, (a[0], a[1], a[2], a[3], b[2], b[3]), a[3].shape[0] + b[3].shape[0]
    if "unary" not in cache:
        cache["unary"] = _spatial_unary(orders, coords, axis, lo, hi, chip_m)
    if expired():
        return None
    a = _spatial_events(sa[3], sb[3], coords, axis, part.size, rest.size, chip_m, True)
    if expired():
        return None
    b = _spatial_events(sb[3], sa[3], coords, axis, rest.size, part.size, chip_m, False)
    return axis, common, (*a, *b, *cache["unary"]), a[1].shape[0] + b[1].shape[0]


def _fill(part, rest, prepared):
    axis, common, events, _ = prepared
    kernel = _fill_contact if axis == 2 else _fill_spatial
    return kernel(part, rest, *common, *events)


def _solve_prepared(orders, coords, indptr, indices, axis, part, rest, chip_m,
                    trank, lo, hi):
    prepared = _prepare_transitions(orders, coords, indptr, indices, axis, part,
                                    rest, chip_m, trank, lo, hi)
    parent, cost, _ = _fill(part, rest, prepared)
    return _traceback(part, rest, parent), cost


def _solve(orders, coords, indptr, indices, axis, part, rest, chip_m):
    """Compatibility entry point for a single fixed-strand merge and probes."""
    trank = _ranks(orders[2])
    lo, hi = _bounds(orders, coords, indptr, indices)
    return _solve_prepared(orders, coords, indptr, indices, axis, part, rest,
                           chip_m, trank, lo, hi)


@njit(cache=True)
def _direct_score(orders, coords, indptr, indices, axis, candidate, chip_m):
    """A whole-set strand has one possible order and needs no merge grid."""
    changed = orders.copy()
    placed = coords.copy()
    changed[axis] = candidate
    if axis < 2:
        for i in range(len(candidate)):
            placed[axis, candidate[i]] = coords[axis, orders[axis, i]]
    return _score(changed, placed, indptr, indices, chip_m, axis)


def interleave(orders, coords, indptr, indices, axis, unit, chip_m, *,
               donors=None, accept_equal=True, deadline=None, info=None,
               checked=True):
    """Compare canonical optimal tracebacks while borrowing either partition side.

    Proper ``unit`` and its complement name the same query. Canonical side B
    is smaller (lexicographically smaller sorted vertices on ties); A is its
    complement. All solves use A first and B second, fixing DP traceback ties
    and minimizing rolling-row width independently of the nomination side.
    Borrow one side's sequence from a CURRENT donor order, forward or reversed;
    keep the other side in destination order. Complete ordered pairs are solved
    once; we never borrow both sides in one solve.

    Equal-cost tracebacks prefer change, genuine borrowing, cyclic donor order,
    forward direction, then borrowed side A before B. A sequence matching either
    destination direction has no borrowed priority. Only each DP's canonical
    traceback is considered, not every tied path. Empty nominations and n <= 1
    are no-ops; whole-set nominations use direct scoring. Destination strands
    are always included, even when ``donors`` restricts borrowing.

    ``accept_equal=False`` retains strict-only adoption for controlled probes.
    Deadlines are checked between candidate kernels; interrupted queries return
    their best completed candidate, including the initial incumbent.
    ``checked=False`` requires validated inputs and checked cost bounds.
    Input arrays are never modified.
    """
    preparation_start = time.perf_counter()
    orders = np.asarray(orders, dtype=np.int64)
    coords = np.asarray(coords, dtype=np.int64)
    indptr = np.asarray(indptr, dtype=np.int64)
    indices = np.asarray(indices, dtype=np.int64)
    axis = int(axis)
    chip_m = int(chip_m)
    if axis not in (0, 1, 2):
        raise ValueError("axis must be 0, 1, or 2")
    if checked:
        _check_inputs(orders, coords, indptr, indices, chip_m, axis)
    n = orders.shape[1]
    allowed = {0, 1, 2} if donors is None else {int(donor) for donor in donors}
    if not allowed <= {0, 1, 2}:
        raise ValueError("donors must contain only axes 0, 1, and 2")
    allowed.add(axis)
    selected = np.zeros(n, dtype=np.bool_)
    for v in unit:
        if not 0 <= int(v) < n:
            raise ValueError("unit contains an invalid vertex")
        selected[int(v)] = True
    size = int(np.count_nonzero(selected))
    whole = size == n and n > 1
    if whole:
        selected[:] = False  # special query: A = V, B = empty
    elif 0 < size < n:
        # Equal-size complements are disjoint: the one containing zero is
        # lexicographically smaller when each side is sorted by vertex id.
        if 2 * size > n or (2 * size == n and not selected[0]):
            selected = ~selected
    order = orders[axis]
    own = (np.ascontiguousarray(order[~selected[order]]),
           np.ascontiguousarray(order[selected[order]]))
    own_pair = (own[0].tobytes(), own[1].tobytes())
    own_keys = [{strand.tobytes(), strand[::-1].tobytes()} for strand in own]
    # Roles, spatial bounds and baseline stay fixed across both directions.
    trank = _ranks(orders[2])
    lo, hi = _bounds(orders, coords, indptr, indices)
    baseline = tuple(int(v) for v in _score_from_bounds(
        orders, coords, indptr, indices, chip_m, axis, lo, hi))
    metrics = dict(baseline_score=baseline, score=baseline, donor=axis,
                   donor_mask=1 << axis, borrowed=False, strict=False,
                   borrow_side=-1, borrow_size=0, candidate_pairs=0,
                   candidate_duplicates=0, complete=True, strand_solves=0, dp_cells=0,
                   direct_scores=0, event_states=0, event_updates=0,
                   strand_preparations=0, traceback_checks=0, tracebacks=0,
                   traceback_wall=0.0,
                   preparation_wall=0.0, dp_wall=0.0,
                   transition_wall=0.0, direct_wall=0.0)
    if info is None:
        info = {}
    donor_order = ((axis + 1) % 3, (axis + 2) % 3, axis)
    candidates = {}
    if size and n > 1:
        sides = (0,) if whole else (0, 1)
        for priority, donor in enumerate(donor_order):
            if donor not in allowed:
                continue
            donor_ordered = orders[donor]
            strands = (donor_ordered[~selected[donor_ordered]],
                       donor_ordered[selected[donor_ordered]])
            for flipped in (False, True):
                for side in sides:
                    strand = strands[side]
                    strand = np.ascontiguousarray(strand[::-1] if flipped else strand)
                    strand_key = strand.tobytes()
                    key = ((strand_key, own_pair[1]) if side == 0 else
                           (own_pair[0], strand_key))
                    borrowed = strand_key not in own_keys[side]
                    provenance = (not borrowed, priority, flipped, side)
                    previous = candidates.get(key)
                    mask = 1 << donor
                    if previous is not None:
                        metrics["candidate_duplicates"] += 1
                        mask |= previous["mask"]
                        if provenance >= previous["provenance"]:
                            previous["mask"] = mask
                            continue
                    candidates[key] = dict(
                        part=strand if side == 0 else own[0],
                        rest=strand if side == 1 else own[1], donor=donor,
                        priority=priority, flipped=flipped, side=side,
                        size=strand.size, mask=mask, borrowed=borrowed,
                        provenance=provenance, incumbent_family=key == own_pair,
                    )
    metrics["candidate_pairs"] = len(candidates)
    # Enumeration follows the selected provenance, not the first pair alias.
    candidates = sorted(candidates.values(), key=lambda c:
                        (c["priority"], c["flipped"], c["side"]))
    metrics["preparation_wall"] = time.perf_counter() - preparation_start
    best, result, chosen = baseline, None, None
    best_parent, best_strands = None, None
    cache = {}
    best_tie = (1, 1, 2, False, 0)  # the unchanged incumbent
    for candidate in candidates:
        part, rest = candidate["part"], candidate["rest"]
        parent = None
        # The full-set incumbent score is already known and needs no kernel.
        if whole and candidate["incumbent_family"]:
            proposed, cost = part, baseline
        else:
            if deadline is not None and time.perf_counter() >= deadline:
                metrics["complete"] = False
                break
            if whole:
                direct_start = time.perf_counter()
                proposed = part
                cost = _direct_score(orders, coords, indptr, indices, axis, part, chip_m)
                metrics["direct_wall"] += time.perf_counter() - direct_start
                metrics["direct_scores"] += 1
            else:
                transition_start = time.perf_counter()
                prepared = _prepare_transitions(
                    orders, coords, indptr, indices, axis, part, rest, chip_m,
                    trank, lo, hi, cache, deadline,
                )
                elapsed = time.perf_counter() - transition_start
                metrics["transition_wall"] += elapsed
                metrics["preparation_wall"] += elapsed
                if prepared is None:
                    metrics["complete"] = False
                    break
                metrics["event_states"] += prepared[3]
                if deadline is not None and time.perf_counter() >= deadline:
                    metrics["complete"] = False
                    break
                dp_start = time.perf_counter()
                parent, cost, updates = _fill(part, rest, prepared)
                metrics["dp_wall"] += time.perf_counter() - dp_start
                metrics["event_updates"] += updates
                metrics["strand_solves"] += 1
                metrics["dp_cells"] += (part.size + 1) * (rest.size + 1) - 1
            cost = tuple(int(v) for v in cost)
        if candidate["incumbent_family"] and cost > baseline:
            raise AssertionError("destination merge lost its available incumbent")
        if cost > best:
            continue
        if whole:
            changed = not np.array_equal(proposed, order)
        elif cost < baseline:
            changed = True
        else:
            metrics["traceback_checks"] += 1
            trace_start = time.perf_counter()
            changed = _trace_differs(part, rest, parent, order)
            metrics["traceback_wall"] += time.perf_counter() - trace_start
        tie = (not changed, not candidate["borrowed"], candidate["priority"],
               candidate["flipped"], candidate["side"])
        if cost < best or (cost == best and tie < best_tie):
            best, chosen, best_tie = cost, candidate, tie
            result = proposed if whole else None
            best_parent, best_strands = parent, (part, rest)
    metrics["strand_preparations"] = sum(isinstance(key, bytes) for key in cache)
    strict = best < baseline
    if chosen is None or best_tie[0] or (not accept_equal and not strict):
        metrics["score"] = baseline
        info.update(metrics)
        return None, False
    if not whole:
        trace_start = time.perf_counter()
        result = _traceback(*best_strands, best_parent)
        metrics["traceback_wall"] += time.perf_counter() - trace_start
        metrics["tracebacks"] = 1
    metrics.update(score=best, donor=chosen["donor"], donor_mask=chosen["mask"],
                   borrowed=chosen["borrowed"], strict=strict,
                   borrow_side=chosen["side"], borrow_size=chosen["size"])
    info.update(metrics)
    return result, bool(chosen["flipped"])
