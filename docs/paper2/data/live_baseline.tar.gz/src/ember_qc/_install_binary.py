"""
ember_qc/_install_binary.py
============================
Download and install pre-built C++ binaries (ATOM, OCT) from GitHub releases.

Binary assets are published to GitHub releases by the `publish-ember-qc.yml`
workflow under tags matching ``ember-qc-v*``.  Asset names follow the pattern::

    {binary}-{platform}        e.g.  atom-darwin-arm64

Install layout under ``get_user_binary_dir()``:

    binaries/
      atom/
        main              ← ATOM executable
        main.version      ← plain-text version string, e.g. "0.5.0"
      oct_based/
        embedding/
          driver          ← OCT executable
          driver.version  ← plain-text version string
"""

from __future__ import annotations

import importlib.util
import json as _json
import os
import platform
import shutil
import stat
import sys
import tempfile
import urllib.error
import urllib.request
from pathlib import Path
from typing import Optional, Tuple

# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------

# GitHub repo that hosts release assets.
# Override with EMBER_GITHUB_REPO if you fork or mirror.
_GITHUB_REPO: str = os.environ.get(
    "EMBER_GITHUB_REPO", "zachmacsmith/ember"
)

# Maps (sys.platform, normalised machine) → asset suffix used in binary names.
_PLATFORM_MAP: dict[tuple[str, str], str] = {
    ("linux",  "x86_64"): "linux-x86_64",
    ("darwin", "arm64"):  "darwin-arm64",
    ("darwin", "x86_64"): "darwin-x86_64",
}

# Known installable binaries: name → path relative to get_user_binary_dir().
_BINARY_REL_PATHS: dict[str, Path] = {
    "atom":   Path("atom") / "main",
    "oct":    Path("oct_based") / "embedding" / "driver",
    # CHARME's per-step helper (a variant of ATOM with incremental-state CLI).
    # Not interchangeable with the regular `atom` binary — see external/CHARME/.
    "charme": Path("charme") / "main",
}

# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------

def _normalise_machine(raw: str) -> str:
    """Normalise platform.machine() output to the keys used in _PLATFORM_MAP."""
    m = raw.lower()
    if m in ("arm64", "aarch64"):
        return "arm64"
    return m


def _version_sidecar(binary_path: Path) -> Path:
    """Return the path of the .version file stored alongside a binary."""
    return binary_path.parent / (binary_path.name + ".version")


def _read_installed_version(binary_path: Path) -> Optional[str]:
    sidecar = _version_sidecar(binary_path)
    if sidecar.exists():
        return sidecar.read_text().strip() or None
    return None


def _write_installed_version(binary_path: Path, version: str) -> None:
    _version_sidecar(binary_path).write_text(version + "\n")

# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def detect_platform() -> Tuple[Optional[str], str]:
    """Return ``(platform_suffix, description)``.

    ``platform_suffix`` is ``None`` when the platform is not supported.
    """
    machine = _normalise_machine(platform.machine())
    sys_name = sys.platform  # e.g. 'linux', 'darwin', 'win32'
    suffix = _PLATFORM_MAP.get((sys_name, machine))
    desc = f"{sys_name}/{machine}"
    return suffix, desc


def resolve_version(version: Optional[str] = None) -> str:
    """Return version string (e.g. ``'0.5.0'``).

    If *version* is given it is returned as-is.  Otherwise the latest
    ``ember-qc-v*`` release tag is fetched from the GitHub API and the
    ``ember-qc-v`` prefix is stripped.

    Raises ``RuntimeError`` on network failure or API rate-limit.
    """
    if version:
        return version

    url = f"https://api.github.com/repos/{_GITHUB_REPO}/releases/latest"
    req = urllib.request.Request(
        url,
        headers={
            "Accept": "application/vnd.github+json",
            "X-GitHub-Api-Version": "2022-11-28",
        },
    )
    try:
        with urllib.request.urlopen(req, timeout=15) as resp:
            data = _json.loads(resp.read())
    except urllib.error.HTTPError as exc:
        if exc.code == 403:
            raise RuntimeError(
                "GitHub API rate limit reached.\n"
                "Specify a version explicitly:  ember install-binary --version X.Y.Z"
            ) from exc
        raise RuntimeError(
            f"GitHub API error ({exc.code}) fetching latest release.\n"
            f"URL: {url}"
        ) from exc
    except Exception as exc:  # noqa: BLE001
        raise RuntimeError(
            f"Network error fetching latest release from GitHub:\n  {exc}\n"
            f"URL: {url}\n"
            "Specify a version explicitly:  ember install-binary --version X.Y.Z"
        ) from exc

    tag: str = data.get("tag_name", "")
    prefix = "ember-qc-v"
    if tag.startswith(prefix):
        return tag[len(prefix):]
    # Unexpected tag format — return as-is and let download fail with a clear URL.
    return tag


def build_asset_url(binary: str, platform_suffix: str, version: str) -> str:
    """Construct the GitHub release asset download URL."""
    tag = f"ember-qc-v{version}"
    asset = f"{binary}-{platform_suffix}"
    return f"https://github.com/{_GITHUB_REPO}/releases/download/{tag}/{asset}"


def install_binary(
    name: str,
    version: Optional[str] = None,
    force: bool = False,
) -> None:
    """Download and install *name* (``'atom'`` or ``'oct'``).

    Raises ``SystemExit`` on unrecoverable error so callers don't need to
    catch anything — the error message is already printed.
    """
    from ember_qc._paths import get_user_binary_dir

    if name not in _BINARY_REL_PATHS:
        known = ", ".join(sorted(_BINARY_REL_PATHS))
        print(f"Unknown binary '{name}'. Known binaries: {known}")
        sys.exit(1)

    dest: Path = get_user_binary_dir() / _BINARY_REL_PATHS[name]

    # ---- already installed? ------------------------------------------------
    if dest.exists() and not force:
        installed_ver = _read_installed_version(dest) or "unknown"
        print(f"{name} is already installed.")
        print(f"  Version : {installed_ver}")
        print(f"  Path    : {dest}")
        print(f"To reinstall:  ember install-binary {name} --force")
        return

    # ---- platform detection ------------------------------------------------
    platform_suffix, platform_desc = detect_platform()
    if platform_suffix is None:
        print(f"Unsupported platform: {platform_desc}")
        print(f"Pre-built binaries are available for: linux/x86_64, darwin/x86_64, darwin/arm64")
        print(f"To build from source, see:  external/{name}/BUILD.md")
        sys.exit(1)

    # ---- version resolution ------------------------------------------------
    try:
        ver = resolve_version(version)
    except RuntimeError as exc:
        print(f"Error: {exc}")
        sys.exit(1)

    url = build_asset_url(name, platform_suffix, ver)
    print(f"Downloading {name} v{ver} for {platform_suffix} ...")
    print(f"  {url}")

    # ---- download to temp file, then move ----------------------------------
    dest.parent.mkdir(parents=True, exist_ok=True)
    tmp_path: Optional[Path] = None
    try:
        # Create temp file in the same directory as the destination so that
        # shutil.move is an atomic rename on the same filesystem.
        fd, tmp_str = tempfile.mkstemp(dir=dest.parent, prefix=f".{name}-download-")
        os.close(fd)
        tmp_path = Path(tmp_str)

        # Use urlopen + explicit status check instead of urlretrieve, which
        # silently saves HTTP error bodies (e.g. GitHub's 404 HTML page) as
        # if they were the requested asset.
        try:
            req = urllib.request.Request(
                url, headers={"User-Agent": "ember-qc-install-binary"}
            )
            with urllib.request.urlopen(req, timeout=60) as resp:
                # urlopen follows redirects; a 200 here means the asset stream
                # is ready to read.  Non-2xx raises HTTPError before reaching
                # this branch.
                if resp.status != 200:
                    raise RuntimeError(
                        f"HTTP {resp.status} {resp.reason} fetching {url}"
                    )
                with open(tmp_path, "wb") as out:
                    shutil.copyfileobj(resp, out)
        except urllib.error.HTTPError as exc:
            # 404 on a release asset usually means the tag exists but the
            # per-platform binary for this version was never uploaded (or the
            # asset naming changed).  Tell the user exactly what to check.
            print(f"Error: HTTP {exc.code} {exc.reason} downloading {name}")
            print(f"  URL: {url}")
            if exc.code == 404:
                print(f"  The release tag 'ember-qc-v{ver}' either does not")
                print(f"  exist or does not publish a '{name}-{platform_suffix}'")
                print(f"  asset. Check https://github.com/{_GITHUB_REPO}/releases")
                print(f"  and/or re-run with --version X.Y.Z to pin a known good release.")
            sys.exit(1)
        except urllib.error.URLError as exc:
            print(f"Network error downloading {name}:")
            print(f"  {exc}")
            print(f"  URL: {url}")
            sys.exit(1)
        except Exception as exc:  # noqa: BLE001
            print(f"Unexpected error while downloading {name}: {exc}")
            print(f"  URL: {url}")
            sys.exit(1)

        # ---- validate downloaded payload is actually a binary -------------
        # Defensive check in case an intermediate proxy rewrites a failed
        # request into a 200 with an HTML error page (seen with some corporate
        # proxies and cached CDN entries).
        try:
            with open(tmp_path, "rb") as fh:
                magic = fh.read(4)
        except OSError as exc:
            print(f"Error: could not read downloaded file: {exc}")
            sys.exit(1)

        # ELF ('\x7fELF'), Mach-O thin ('\xcf\xfa\xed\xfe', '\xce\xfa\xed\xfe'),
        # or Mach-O universal ('\xca\xfe\xba\xbe').
        valid_magics = {
            b"\x7fELF",
            b"\xcf\xfa\xed\xfe",
            b"\xce\xfa\xed\xfe",
            b"\xca\xfe\xba\xbe",
        }
        if magic not in valid_magics:
            size = tmp_path.stat().st_size if tmp_path.exists() else 0
            print(f"Error: downloaded file is not a valid executable.")
            print(f"  Expected ELF or Mach-O magic bytes, got: {magic!r}")
            print(f"  File size: {size} bytes")
            print(f"  URL: {url}")
            # Show a snippet if it looks like text (likely an HTML error page).
            if magic[:1] in (b"<", b"{", b" ", b"\n", b"\r"):
                try:
                    snippet = tmp_path.read_text(errors="replace")[:500]
                    print(f"  Content preview:\n    {snippet!r}")
                except OSError:
                    pass
            sys.exit(1)

        shutil.move(str(tmp_path), dest)
        tmp_path = None  # ownership transferred

    finally:
        if tmp_path is not None and tmp_path.exists():
            tmp_path.unlink()

    # ---- set executable permissions ----------------------------------------
    dest.chmod(dest.stat().st_mode | stat.S_IXUSR | stat.S_IXGRP | stat.S_IXOTH)

    # ---- write version sidecar ---------------------------------------------
    _write_installed_version(dest, ver)

    # ---- per-binary post-install scaffolding ------------------------------
    # CHARME's C++ helper writes per-call scratch files to `./atom_log/PPO.txt`
    # relative to its own directory. Create that directory so the binary has
    # somewhere to write on its first invocation.
    # Also download the weights file (~144 KB) from the same release.
    if name == "charme":
        (dest.parent / "atom_log").mkdir(parents=True, exist_ok=True)

        weights_dest = dest.parent / "ppo_CHARME_ep1800.pth"
        if not weights_dest.exists():
            weights_url = f"https://github.com/{_GITHUB_REPO}/releases/download/ember-qc-v{ver}/ppo_CHARME_ep1800.pth"
            print(f"Downloading CHARME weights ({weights_url}) ...")
            try:
                urllib.request.urlretrieve(weights_url, weights_dest)
                print(f"  → {weights_dest}")
            except Exception as exc:
                print(
                    f"Warning: could not download CHARME weights: {exc}\n"
                    f"Set EMBER_CHARME_WEIGHTS=/path/to/ppo_CHARME_ep1800.pth to use a local copy."
                )
        else:
            print(f"CHARME weights already present at {weights_dest}")

        missing_py = [p for p in ("torch", "torch_geometric")
                      if importlib.util.find_spec(p) is None]
        if missing_py:
            print(
                "\nCHARME binary installed. To enable the Python inference layer, "
                "install the required packages:\n"
                "  pip install ember-qc[charme]\n"
                "(torch and torch_geometric are large; see https://pytorch-geometric.readthedocs.io "
                "if you need a specific CUDA build.)"
            )

    # ---- verify ------------------------------------------------------------
    # Neither ATOM nor OCT expose a --version flag; verification is a
    # simple existence + executable-bit check.
    if not dest.exists():
        print(f"Error: binary not found at expected path after install: {dest}")
        sys.exit(1)
    if not os.access(dest, os.X_OK):
        print(f"Error: binary at {dest} is not executable after install")
        sys.exit(1)

    print(f"Installed and verified: {name} → {dest}")


def list_binaries() -> None:
    """Print a formatted table of all known binaries and their install status."""
    from ember_qc._paths import get_user_binary_dir

    binary_dir = get_user_binary_dir()

    col_name    = 8
    col_status  = 15
    col_version = 9
    ruler = "─" * 72

    print(f"{'Binary':<{col_name}}  {'Status':<{col_status}}  {'Version':<{col_version}}  Path")
    print(ruler)

    for name, rel_path in _BINARY_REL_PATHS.items():
        path = binary_dir / rel_path
        if path.exists() and os.access(path, os.X_OK):
            ver = _read_installed_version(path) or "unknown"
            status = "✓ installed"
            display = str(path)
        elif path.exists():
            ver = _read_installed_version(path) or "unknown"
            status = "! not executable"
            display = str(path)
        else:
            ver = ""
            status = "✗ not installed"
            display = f"run: ember install-binary {name}"
        print(f"{name:<{col_name}}  {status:<{col_status}}  {ver:<{col_version}}  {display}")
